<template>
    <div class="w-1/3 bg-white p-4 border-r border-gray-400">
        <h2 class="font-bold text-2xl tracking-tight">Home</h2>
    </div>
</template>

<script>
    export default {
        name: "Sidebar"
    }
</script>

<style scoped>

</style>
