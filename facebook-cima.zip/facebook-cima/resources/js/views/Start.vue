<template>
    <div>sdflksjdflkjsd</div>
</template>

<script>
    export default {
        name: "Start"
    }
</script>

<style scoped>

</style>
